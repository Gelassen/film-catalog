package com.agoda.news.sample.converters;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import com.agoda.news.sample.pojo.NewsEntity;

public class NewsResultsConverter implements IConverter<List<NewsEntity>, JSONObject> {

    private final IConverter<NewsEntity, JSONObject> converter;

    public NewsResultsConverter() {
        converter = new NewsEntityConverter();
    }

    @Override
    public List<NewsEntity> convert(JSONObject json) throws JSONException {
        List<NewsEntity> results = new ArrayList<>();
        JSONArray resultArray = json.getJSONArray("results");
        for (int i = 0; i < resultArray.length(); i++) {
            JSONObject newsObject = resultArray.getJSONObject(i);
            NewsEntity newsEntity = converter.convert(newsObject);
            results.add(newsEntity);
        }
        return results;
    }
}
