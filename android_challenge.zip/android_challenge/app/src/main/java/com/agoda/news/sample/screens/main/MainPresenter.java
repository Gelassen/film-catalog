package com.agoda.news.sample.screens.main;


import java.util.List;

import com.agoda.news.sample.Callback;
import com.agoda.news.sample.pojo.NewsEntity;
import com.agoda.news.sample.screens.main.providers.NewsProvider;

public class MainPresenter implements MainContract.Presenter, Callback {

    private final NewsProvider provider;
    private MainContract.View view;

    private boolean isWorkInBackground;

    public MainPresenter() {
        provider = new NewsProvider();
    }

    @Override
    public void attachView(MainContract.View view) {
        this.view = view;
    }

    @Override
    public void onLoadData() {
        isWorkInBackground = true;
        provider.loadResource(this);
    }

    @Override
    public void onResult(List<NewsEntity> result) {
        isWorkInBackground = false;
        view.showData(result);
    }

    // TODO see ListIdlingResource
    public boolean isWorkInBackground() {
        return isWorkInBackground;
    }
}
