package com.agoda.news.sample.screens.main;


import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.agoda.news.sample.App;
import com.agoda.news.sample.Navigator;
import com.agoda.news.sample.R;
import com.agoda.news.sample.pojo.NewsEntity;

import java.util.ArrayList;
import java.util.List;

public class NewsMainFragment extends Fragment implements MainContract.View, NewsListAdapter.ListClickListener {

    private static final String EXTRA_KEY_TABLET_MODE = "EXTRA_KEY_TABLET_MODE";

    public static NewsMainFragment newInstance(boolean isTabletModeOn) {
        NewsMainFragment fragment = new NewsMainFragment();
        Bundle args = new Bundle();
        args.putBoolean(EXTRA_KEY_TABLET_MODE, isTabletModeOn);
        fragment.setArguments(args);
        return fragment;
    }

    private Navigator navigator;
    private NewsListAdapter adapter;
    private MainPresenter presenter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.screen_main, container, false);
        navigator = new Navigator(getFragmentManager(), view, getArguments().getBoolean(EXTRA_KEY_TABLET_MODE));
        ListView listView = (ListView) view.findViewById(android.R.id.list);
        adapter = new NewsListAdapter(getActivity(), R.layout.list_item_news, new ArrayList<NewsEntity>(), this);
        listView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(adapter);
        presenter = new MainPresenter();
        presenter.attachView(this);
        presenter.onLoadData();
        return view;
    }

    @Override
    public void showData(final List<NewsEntity> list) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                adapter.setData(list);
            }
        });
    }

    @Override
    public void onItemClick(NewsEntity newsEntity) {
        navigator.onItemClick(getActivity(), newsEntity);
    }

    public MainContract.Presenter getPresenter() {
        return presenter;
    }


}
