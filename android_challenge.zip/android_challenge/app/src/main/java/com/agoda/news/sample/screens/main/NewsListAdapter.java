package com.agoda.news.sample.screens.main;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import com.agoda.news.sample.pojo.MediaEntity;
import com.agoda.news.sample.pojo.NewsEntity;
import com.agoda.news.sample.R;
import com.squareup.picasso.Picasso;

class NewsListAdapter extends ArrayAdapter<NewsEntity> implements AdapterView.OnItemClickListener {

    private static final int NONE = -1;

    private ListClickListener listener;

    public NewsListAdapter(Context context, int resource, List<NewsEntity> objects, ListClickListener listener) {
        super(context, resource, objects);
        this.listener = listener;
    }

    public void setData(List<NewsEntity> list) {
        clear();
        addAll(list);
        notifyDataSetChanged();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        NewsEntity newsEntity = getItem(position);
        List<MediaEntity> mediaEntityList = newsEntity.getMediaEntity();
        ViewHolder viewHolder;
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.list_item_news, parent, false);
            viewHolder = new ViewHolder(convertView);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        viewHolder.newsTitle.setText(newsEntity.getTitle());
        String thumbnailURL = mediaEntityList.size() == 0 ? newsEntity.getArticleUrl() : mediaEntityList.get(0).getUrl();
        Picasso.get().load(Uri.parse(thumbnailURL))
                .centerCrop()
                .fit()
                .into(viewHolder.imageView);
        return convertView;
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        NewsEntity newsEntity = getItem(position);
        if (listener != null) {
            listener.onItemClick(newsEntity);
        }
    }

    public interface ListClickListener {
        void onItemClick(NewsEntity newsEntity);
    }

    private class ViewHolder {
        final View root;
        final TextView newsTitle;
        final ImageView imageView;

        public ViewHolder(View view) {
            this.root = view.findViewById(R.id.root);
            this.newsTitle = (TextView) view.findViewById(R.id.news_title);
            this.imageView = (ImageView) view.findViewById(R.id.news_item_image);
            root.setSelected(true);
        }

    }

}
