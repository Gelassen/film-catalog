package com.agoda.news.sample.screens.main;


import java.util.List;

import com.agoda.news.sample.pojo.NewsEntity;

interface MainContract {

    interface View {
        void showData(List<NewsEntity> list);
    }

    interface Presenter {
        void attachView(View view);

        void onLoadData();
    }
}
