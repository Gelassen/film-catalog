package com.agoda.news.sample.network;



import io.reactivex.Observable;
import com.agoda.news.sample.pojo.NewsEntity;
import retrofit2.http.GET;

public interface ApiService {

    @GET("/nl6jh")
    Observable<NewsEntity> getContent();

}
