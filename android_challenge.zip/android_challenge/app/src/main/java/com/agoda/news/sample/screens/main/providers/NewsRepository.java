package com.agoda.news.sample.screens.main.providers;


import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import io.reactivex.Observable;
import com.agoda.news.sample.Callback;
import com.agoda.news.sample.pojo.NewsEntity;
import com.agoda.news.sample.converters.NewsResultsConverter;
import com.agoda.news.sample.network.ApiService;
import com.agoda.news.sample.network.NetworkService;

public class NewsRepository implements ApiService {

    private final NetworkService service;

    public NewsRepository() {
        service = new NetworkService();
    }

    @Override
    public Observable<NewsEntity> getContent() {
        return service.getApi().getContent();
    }

    public void loadResource(final Callback callback) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL("https://api.myjson.com/bins/nl6jh");
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    String readStream = readStream(con.getInputStream());
                    NewsResultsConverter converter = new NewsResultsConverter();
                    callback.onResult(converter.convert(new JSONObject(readStream)));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private static String readStream(InputStream in) {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(in))) {

            String nextLine = "";
            while ((nextLine = reader.readLine()) != null) {
                sb.append(nextLine);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }
}
