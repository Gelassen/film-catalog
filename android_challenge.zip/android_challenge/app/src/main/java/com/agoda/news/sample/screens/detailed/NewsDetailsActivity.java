package com.agoda.news.sample.screens.detailed;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.agoda.news.sample.pojo.NewsEntity;
import com.agoda.news.sample.R;

/**
 * News detail view
 */
public class NewsDetailsActivity extends Activity {

    public static void start(Context context, NewsEntity entity) {
        Intent intent = new Intent(context, NewsDetailsActivity.class);
        intent.putExtras(NewsDetailedFragment.getPassArgsAsBundle(entity));
        context.startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed);

        getFragmentManager().beginTransaction()
                .replace(R.id.main, NewsDetailedFragment.newInstance(getIntent().getExtras()), NewsDetailedFragment.TAG)
                .commit();
    }

}
