package com.agoda.news.sample.converters;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Class to convert json from server to valid one for JSONObject&JSONArray mappings
 * */
public class JsonValidatorConverter implements IConverter<JSONObject, JSONObject> {


    @Override
    public JSONObject convert(JSONObject entity) throws JSONException {
        // multimedia field sometimes has string type "" instead of empty array []
        String correctField = "multimedia";
        try {
            JSONArray array = entity.getJSONArray(correctField);
        } catch (Exception ex) {
            entity.put(correctField, new JSONArray());
        }

        return entity;
    }
}
