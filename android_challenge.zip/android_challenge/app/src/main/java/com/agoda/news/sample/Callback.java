package com.agoda.news.sample;

import java.util.List;

import com.agoda.news.sample.pojo.NewsEntity;

public interface Callback {
    void onResult(List<NewsEntity> result);
}
