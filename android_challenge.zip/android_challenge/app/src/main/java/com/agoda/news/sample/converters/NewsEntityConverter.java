package com.agoda.news.sample.converters;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import com.agoda.news.sample.pojo.MediaEntity;
import com.agoda.news.sample.pojo.NewsEntity;

public class NewsEntityConverter implements IConverter<NewsEntity, JSONObject> {

    private final IConverter<MediaEntity, JSONObject> converter;
    private final IConverter<JSONObject, JSONObject> validator;

    public NewsEntityConverter() {
        converter = new MediaEntityConverter();
        validator = new JsonValidatorConverter();
    }

    @Override
    public NewsEntity convert(JSONObject entity) throws JSONException {
        if (entity == null) return new NewsEntity();
        entity = validator.convert(entity);

        NewsEntity result = new NewsEntity();
        result.setTitle(entity.optString("title", ""));
        result.setSummary(entity.optString("abstract", ""));
        result.setArticleUrl(entity.optString("url", ""));
        result.setByline(entity.optString("byline", ""));
        result.setPublishedDate(entity.optString("published_date", ""));

        List<MediaEntity> list = new ArrayList<>();
        JSONArray mediaArray = entity.getJSONArray("multimedia");

        for (int id = 0; id < mediaArray.length(); id++) {
            MediaEntity mediaEntity = converter.convert((JSONObject) mediaArray.get(id));
            list.add(mediaEntity);
        }
        result.setMediaEntityList(list);
        return result;
    }
}
