package com.agoda.news.sample;


import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.util.Log;
import android.view.View;

import com.agoda.news.sample.pojo.NewsEntity;
import com.agoda.news.sample.screens.PlaceholderFragment;
import com.agoda.news.sample.screens.detailed.NewsDetailsActivity;
import com.agoda.news.sample.screens.detailed.NewsDetailedFragment;
import com.agoda.news.sample.screens.main.NewsMainFragment;

public class Navigator {

    private final FragmentManager fm;
    private final View root;
    private final boolean isTwoPaneMode;

    public Navigator(FragmentManager fm, View root) {
        this(fm, root, false);
    }

    public Navigator(FragmentManager fm, View root, boolean isTwoPaneMode) {
        this.fm = fm;
        this.root = root;
        this.isTwoPaneMode = isTwoPaneMode;
    }

    public void show() {
        if (isTwoPaneMode()) {
            showMain();
            showDetailedPlaceholder();
        } else {
            showMain();
        }
    }

    public void onItemClick(Activity activity, final NewsEntity newsEntity) {
        if (isTwoPaneMode()) { // landscape mode on tablets
            showDetailed(newsEntity);
        } else { // unified way for smartphones
            // TODO replace on fragment change in the same fragment
            NewsDetailsActivity.start(activity, newsEntity);
        }
    }

    private boolean isTwoPaneMode() {
        return root.findViewById(R.id.detailed) != null || isTwoPaneMode;
    }

    private void showMain() {
        fm.beginTransaction()
                .replace(R.id.main, NewsMainFragment.newInstance(isTwoPaneMode()), NewsDetailedFragment.TAG)
                .commit();
    }

    private void showDetailed(final NewsEntity newsEntity) {
        fm.beginTransaction()
                .replace(R.id.detailed, NewsDetailedFragment.newInstance(newsEntity), NewsDetailedFragment.TAG)
                .commit();
    }

    private void showDetailedPlaceholder() {
        fm.beginTransaction()
                .replace(R.id.detailed, PlaceholderFragment.newInstance(), PlaceholderFragment.TAG)
                .commit();
    }
}
