package com.agoda.news.sample.converters;


import org.json.JSONException;

interface IConverter<T,P> {

    T convert(P entity) throws JSONException;

}
