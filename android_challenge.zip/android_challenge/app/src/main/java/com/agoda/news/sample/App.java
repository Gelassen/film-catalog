package com.agoda.news.sample;


public class App {
    public static final String TAG = "TAG";
    public static final String DEBUG = "DEBUG";
}
