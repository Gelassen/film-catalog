package com.agoda.news.sample.screens.main.providers;



import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import com.agoda.news.sample.Callback;
import com.agoda.news.sample.pojo.NewsEntity;

public class NewsProvider {

    private final NewsRepository repo;

    public NewsProvider() {
        repo = new NewsRepository();
    }

    public Observable<NewsEntity> provideData() {
        return repo.getContent()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io());
    }

    public void loadResource(Callback callback) {
        repo.loadResource(callback);
    }
}
