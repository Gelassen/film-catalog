package com.agoda.news.sample.pojo;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * This represents a news item
 */
public class NewsEntity {

    @SerializedName("title")
    private String title;
    @SerializedName("abstract")
    private String summary;
    @SerializedName("url")
    private String articleUrl;
    @SerializedName("byline")
    private String byline;
    @SerializedName("published_date")
    private String publishedDate;
    @SerializedName("multimedia")
    private List<MediaEntity> mediaEntityList;

    public NewsEntity() {
        mediaEntityList = new ArrayList<>();
    }

    public String getTitle() {
        return title;
    }

    public String getSummary() {
        return summary;
    }

    public String getArticleUrl() {
        return articleUrl;
    }

    public String getByline() {
        return byline;
    }

    public String getPublishedDate() {
        return publishedDate;
    }

    public List<MediaEntity> getMediaEntity() {
        return mediaEntityList;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public void setArticleUrl(String articleUrl) {
        this.articleUrl = articleUrl;
    }

    public void setByline(String byline) {
        this.byline = byline;
    }

    public void setPublishedDate(String publishedDate) {
        this.publishedDate = publishedDate;
    }

    public void setMediaEntityList(List<MediaEntity> mediaEntityList) {
        this.mediaEntityList = mediaEntityList;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        NewsEntity entity = (NewsEntity) o;

        if (title != null ? !title.equals(entity.title) : entity.title != null) return false;
        if (summary != null ? !summary.equals(entity.summary) : entity.summary != null)
            return false;
        if (articleUrl != null ? !articleUrl.equals(entity.articleUrl) : entity.articleUrl != null)
            return false;
        if (byline != null ? !byline.equals(entity.byline) : entity.byline != null) return false;
        if (publishedDate != null ? !publishedDate.equals(entity.publishedDate) : entity.publishedDate != null)
            return false;
        return mediaEntityList != null ? mediaEntityList.equals(entity.mediaEntityList) : entity.mediaEntityList == null;
    }

    @Override
    public int hashCode() {
        int result = title != null ? title.hashCode() : 0;
        result = 31 * result + (summary != null ? summary.hashCode() : 0);
        result = 31 * result + (articleUrl != null ? articleUrl.hashCode() : 0);
        result = 31 * result + (byline != null ? byline.hashCode() : 0);
        result = 31 * result + (publishedDate != null ? publishedDate.hashCode() : 0);
        result = 31 * result + (mediaEntityList != null ? mediaEntityList.hashCode() : 0);
        return result;
    }
}
