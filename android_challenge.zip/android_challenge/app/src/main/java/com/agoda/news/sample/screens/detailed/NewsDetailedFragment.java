package com.agoda.news.sample.screens.detailed;


import android.app.Fragment;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.agoda.news.sample.R;
import com.agoda.news.sample.pojo.NewsEntity;
import com.squareup.picasso.Picasso;

public class NewsDetailedFragment extends Fragment {

    public static final String TAG = NewsDetailedFragment.class.getName();

    private static final String EXTRA_KEY_STORY_URL = "EXTRA_KEY_STORY_URL";
    private static final String EXTRA_KEY_TITLE = "EXTRA_KEY_TITLE";
    private static final String EXTRA_KEY_SUMMARY = "EXTRA_KEY_SUMMARY";
    private static final String EXTRA_KEY_IMAGE_URL = "EXTRA_KEY_IMAGE_URL";

    public static NewsDetailedFragment newInstance(Bundle args) {
        NewsDetailedFragment fragment = new NewsDetailedFragment();
        fragment.setArguments(args);
        return fragment;
    }

    public static NewsDetailedFragment newInstance(NewsEntity entity) {
        NewsDetailedFragment fragment = new NewsDetailedFragment();
        fragment.setArguments(getPassArgsAsBundle(entity));
        return fragment;
    }

    public static Bundle getPassArgsAsBundle(NewsEntity entity) {
        Bundle args = new Bundle();
        args.putString(EXTRA_KEY_STORY_URL, entity.getArticleUrl());
        args.putString(EXTRA_KEY_TITLE, entity.getTitle());
        args.putString(EXTRA_KEY_SUMMARY, entity.getSummary());
        args.putString(EXTRA_KEY_IMAGE_URL, entity.getMediaEntity().size() == 0 ? "" : entity.getMediaEntity().get(0).getUrl());
        return args;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.screen_detail, container, false);

        Bundle extras = getArguments();
        ((TextView) view.findViewById(R.id.title))
                .setText(extras.getString(EXTRA_KEY_TITLE, ""));
        ((TextView) view.findViewById(R.id.summary_content))
                .setText(extras.getString(EXTRA_KEY_SUMMARY, ""));

        Picasso.get()
                .load(Uri.parse(extras.getString(EXTRA_KEY_IMAGE_URL, "")))
                .placeholder(R.drawable.ic_placeholder)
                .centerCrop()
                .fit()
                .into((ImageView) view.findViewById(R.id.news_image));

        final String storyURL = extras.getString(EXTRA_KEY_STORY_URL, "");
        Button btn = (Button) view.findViewById(R.id.full_story_link);
        btn.setEnabled(!TextUtils.isEmpty(storyURL));
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(storyURL));
                startActivity(intent);
            }
        });
        return view;
    }

}
