package com.agoda.news.sample.converters;


import org.json.JSONException;
import org.json.JSONObject;

import com.agoda.news.sample.pojo.MediaEntity;

public class MediaEntityConverter implements IConverter<MediaEntity, JSONObject> {

    @Override
    public MediaEntity convert(JSONObject jsonObject) throws JSONException {
        MediaEntity mediaEntity = new MediaEntity();

        if (jsonObject == null) return mediaEntity;

        mediaEntity.setUrl(jsonObject.optString("url", ""));
        mediaEntity.setFormat(jsonObject.optString("format", ""));
        mediaEntity.setHeight(jsonObject.optInt("height", 0));
        mediaEntity.setWidth(jsonObject.optInt("width", 0));
        mediaEntity.setType(jsonObject.optString("type", ""));
        mediaEntity.setSubType(jsonObject.optString("subtype", ""));
        mediaEntity.setCaption(jsonObject.optString("caption", ""));
        mediaEntity.setCopyright(jsonObject.optString("copyright", ""));
        return mediaEntity;
    }
}
