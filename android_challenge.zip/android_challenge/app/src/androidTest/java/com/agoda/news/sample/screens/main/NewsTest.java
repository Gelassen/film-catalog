package com.agoda.news.sample.screens.main;


import android.support.test.espresso.Espresso;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;

import com.agoda.news.sample.ListIdlingResource;
import com.agoda.news.sample.robots.NewsRobot;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;


@LargeTest
@RunWith(AndroidJUnit4.class)
public class NewsTest {

    @Rule
    public ActivityTestRule<MainActivity> activityTestRule = new ActivityTestRule<>(MainActivity.class);

    private NewsRobot robot = new NewsRobot();

    private ListIdlingResource listIdlingResource;

    @Before
    public void setUp() throws Exception {
        this.listIdlingResource = new ListIdlingResource(activityTestRule.getActivity());
        Espresso.registerIdlingResources(listIdlingResource);
    }

    @After
    public void tearDown() throws Exception {
        Espresso.unregisterIdlingResources(listIdlingResource);
    }

    @Test
    public void mainActivityTest() {
        robot
                .seesNewsList()
                .seesValidThirdItem()
                .openNewsDetails();
    }
}
