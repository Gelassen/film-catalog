package com.agoda.news.sample.robots;


import android.support.test.espresso.DataInteraction;
import android.support.test.espresso.ViewInteraction;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import com.agoda.news.sample.R;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;

import static android.support.test.espresso.Espresso.onData;
import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.anything;

public class NewsRobot {

    public NewsRobot seesNewsList() {
        onView(withId(android.R.id.list))
                .check(matches(isDisplayed()));
        return this;
    }

    public NewsRobot seesValidThirdItem() {
        seesThirdElement();
        seesImageAtTheListItem();
        seesTextTitleAtTheListItem();
        return this;
    }

    private NewsRobot seesThirdElement() {
        ViewInteraction linearLayout = onView(
                allOf(childAtPosition(
                        allOf(withId(android.R.id.list),
                                childAtPosition(
                                        withId(R.id.root),
                                        0)),
                        2),
                        isDisplayed()));
        linearLayout.check(matches(isDisplayed()));
        return this;
    }

    private NewsRobot seesImageAtTheListItem() {
        ViewInteraction imageView = onView(
                allOf(withId(R.id.news_item_image),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.list),
                                        2),
                                0),
                        isDisplayed()));
        imageView.check(matches(isDisplayed()));
        return this;
    }

    private NewsRobot seesTextTitleAtTheListItem() {
        ViewInteraction textView = onView(
                allOf(withId(R.id.news_title), withText("Jeff Bezos and Amazon Employees Join Debate Over Its Culture"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.list),
                                        2),
                                1),
                        isDisplayed()));
        textView.check(matches(withText("Jeff Bezos and Amazon Employees Join Debate Over Its Culture")));
        return this;
    }

    private static Matcher<View> childAtPosition(
            final Matcher<View> parentMatcher, final int position) {

        return new TypeSafeMatcher<View>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("Child at position " + position + " in parent ");
                parentMatcher.describeTo(description);
            }

            @Override
            public boolean matchesSafely(View view) {
                ViewParent parent = view.getParent();
                return parent instanceof ViewGroup && parentMatcher.matches(parent)
                        && view.equals(((ViewGroup) parent).getChildAt(position));
            }
        };
    }

    public void openNewsDetails() {
        DataInteraction linearLayout2 = onData(anything())
                .inAdapterView(allOf(withId(android.R.id.list),
                        childAtPosition(
                                withId(R.id.root),
                                0)))
                .atPosition(2);
        linearLayout2.perform(click());
    }
}
