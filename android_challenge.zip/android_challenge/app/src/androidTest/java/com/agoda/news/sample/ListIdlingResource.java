package com.agoda.news.sample;


import android.app.FragmentManager;
import android.support.test.espresso.IdlingResource;
import android.support.test.rule.ActivityTestRule;

import com.agoda.news.sample.screens.main.MainActivity;
import com.agoda.news.sample.screens.main.MainPresenter;
import com.agoda.news.sample.screens.main.NewsMainFragment;

import org.junit.Rule;

// TODO replace it with OkHttp idling resource {@link https://github.com/JakeWharton/okhttp-idling-resource} when complete transition to retrofit
public class ListIdlingResource implements IdlingResource {

    @Rule
    public ActivityTestRule<MainActivity> activityTestRule = new ActivityTestRule<>(MainActivity.class);

    private ResourceCallback resourceCallback;
    private MainActivity activity;

    public ListIdlingResource(MainActivity activity) {
        this.activity = activity;
    }

    @Override
    public String getName() {
        return ListIdlingResource.class.getName();
    }

    @Override
    public boolean isIdleNow() {
        FragmentManager fm = activity.getFragmentManager();
        NewsMainFragment mainFragment = (NewsMainFragment) fm.findFragmentByTag(NewsMainFragment.TAG);
        MainPresenter presenter = (MainPresenter) mainFragment.getPresenter();

        if (presenter.isWorkInBackground()) {
            return false;
        } else {
            resourceCallback.onTransitionToIdle();
            return true;
        }
    }

    @Override
    public void registerIdleTransitionCallback(ResourceCallback callback) {
        this.resourceCallback = callback;
    }
}
