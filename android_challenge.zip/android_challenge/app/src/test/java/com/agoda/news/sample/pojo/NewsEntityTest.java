package com.agoda.news.sample.pojo;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import java.util.List;

public class NewsEntityTest {


    private NewsEntity subject;

    @Before
    public void setUp() throws Exception {
        subject = new NewsEntity();
    }

    @Test
    public void testGetMediaEntity_onDefaultStateCheckSize_expectNoException() throws Exception {
        List<MediaEntity> list = subject.getMediaEntity();

        Assert.assertNotNull(list);
        Assert.assertEquals(0, list.size());
    }

}