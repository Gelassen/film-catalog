package com.agoda.news.sample.converters;

import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;

import com.agoda.news.sample.pojo.MediaEntity;

import static org.mockito.Mockito.when;

/**
 * NOTE: I didn't cover all possible use cases, just the most important from my perspective.
 *
 * In general amount of cases covered by tests depends on the team policy.
 *
 * */
public class MediaEntityConverterTest {

    private final MediaEntityConverter subject = new MediaEntityConverter();

    @Test
    public void testConvert_passNull_expectEmptyObject() throws Exception {
        MediaEntity result = subject.convert(null);

        Assert.assertEquals(new MediaEntity(), result);
    }

    @Test
    public void testConvert_passCorrectJson_expectCorrectEntity() throws Exception {
        JSONObject mock = Mockito.mock(JSONObject.class);
        when(mock.optString("url", "")).thenReturn("http://static01.nyt.com/images/2015/08/18/business/18db-whitecollar-web/18db-whitecollar-web-thumbStandard.jpg");
        when(mock.optString("format", "")).thenReturn("Standard Thumbnail");
        when(mock.optInt("height", 0)).thenReturn(75);
        when(mock.optInt("width", 0)).thenReturn(75);
        when(mock.optString("type", "")).thenReturn("image");
        when(mock.optString("subtype", "")).thenReturn("photo");
        when(mock.optString("caption", "")).thenReturn("Jeh Johnson, the Secretary of Homeland Security, left, and Paul J. Fishman, United States Attorney for the District of New Jersey, center, after a news conference in Newark on Tuesday.");
        when(mock.optString("copyright", "")).thenReturn("Karsten Moran for The New York Times");

        MediaEntity expected = new MediaEntity();
        expected.setUrl("http://static01.nyt.com/images/2015/08/18/business/18db-whitecollar-web/18db-whitecollar-web-thumbStandard.jpg");
        expected.setFormat("Standard Thumbnail");
        expected.setHeight(75);
        expected.setWidth(75);
        expected.setType("image");
        expected.setSubType("photo");
        expected.setCaption("Jeh Johnson, the Secretary of Homeland Security, left, and Paul J. Fishman, United States Attorney for the District of New Jersey, center, after a news conference in Newark on Tuesday.");
        expected.setCopyright("Karsten Moran for The New York Times");

        MediaEntity result = subject.convert(mock);

        Assert.assertEquals(result, expected);
    }

    @Test
    public void testConvert_passNotCorrectJson_expectNotCorrectEntity() throws Exception {
        JSONObject mock = Mockito.mock(JSONObject.class);
        when(mock.optString("url", "")).thenReturn("http://static01.nyt.com/images/2015/08/18/business/18db-whitecollar-web/18db-whitecollar-web-thumbStandard.jpg");
        when(mock.optString("format", "")).thenReturn("Standard Thumbnail");
        when(mock.optInt("height", 0)).thenReturn(75);
        when(mock.optInt("width", 0)).thenReturn(75);
        when(mock.optString("type", "")).thenReturn("image");
        when(mock.optString("subtype", "")).thenReturn("photo");
        when(mock.optString("caption", "")).thenReturn("");
        when(mock.optString("copyright", "")).thenReturn("");

        MediaEntity expected = new MediaEntity();
        expected.setUrl("http://static01.nyt.com/images/2015/08/18/business/18db-whitecollar-web/18db-whitecollar-web-thumbStandard.jpg");
        expected.setFormat("Standard Thumbnail");
        expected.setHeight(75);
        expected.setWidth(75);
        expected.setType("image");
        expected.setSubType("photo");
        expected.setCaption("");
        expected.setCopyright("");

        MediaEntity result = subject.convert(mock);

        Assert.assertEquals(result, expected);
    }
}