package com.agoda.news.sample.converters;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.Collections;

import com.agoda.news.sample.pojo.MediaEntity;
import com.agoda.news.sample.pojo.NewsEntity;

import static org.mockito.Mockito.when;

public class NewsEntityConverterTest {

    private final NewsEntityConverter subject = new NewsEntityConverter();

    @Test
    public void testConvert_passNull_expectEmptyObject() throws Exception {
        NewsEntity entity = subject.convert(null);

        Assert.assertEquals(new NewsEntity(), entity);
    }

    @Test
    public void testConvert_passCorrectValueWithEmptyMultimedia_expectCorrectEntity() throws Exception {
        JSONArray jsonArray = Mockito.mock(JSONArray.class);
        when(jsonArray.length()).thenReturn(0);

        JSONObject mock = Mockito.mock(JSONObject.class);
        when(mock.optString("title", "")).thenReturn("Hacking Case Raises Question on Securities Fraud");
        when(mock.optString("abstract", "")).thenReturn("Stealing corporate information from computers to make trades certainly looks like insider trading, but it can depend on court jurisdiction.");
        when(mock.optString("url", "")).thenReturn("http://www.nytimes.com/2015/08/18/business/dealbook/hacking-case-raises-question-on-securities-fraud.html");
        when(mock.optString("byline", "")).thenReturn("By PETER J. HENNING");
        when(mock.optString("published_date", "")).thenReturn("2015-08-18T04:00:00-5:00");
        when(mock.getJSONArray("multimedia")).thenReturn(jsonArray);

        NewsEntity expected = new NewsEntity();
        expected.setTitle("Hacking Case Raises Question on Securities Fraud");
        expected.setSummary("Stealing corporate information from computers to make trades certainly looks like insider trading, but it can depend on court jurisdiction.");
        expected.setArticleUrl("http://www.nytimes.com/2015/08/18/business/dealbook/hacking-case-raises-question-on-securities-fraud.html");
        expected.setByline("By PETER J. HENNING");
        expected.setPublishedDate("2015-08-18T04:00:00-5:00");
        expected.setMediaEntityList(Collections.<MediaEntity>emptyList());

        NewsEntity result = subject.convert(mock);

        Assert.assertEquals(expected, result);
    }

    @Test
    public void testConvert_passNotCorrectValueWithEmptyMultimedia_expectCorrectEntity() throws Exception {
        JSONArray jsonArray = Mockito.mock(JSONArray.class);
        when(jsonArray.length()).thenReturn(0);

        JSONObject mock = Mockito.mock(JSONObject.class);
        when(mock.optString("title", "")).thenReturn("Hacking Case Raises Question on Securities Fraud");
        when(mock.optString("abstract", "")).thenReturn("Stealing corporate information from computers to make trades certainly looks like insider trading, but it can depend on court jurisdiction.");
        when(mock.optString("url", "")).thenReturn("http://www.nytimes.com/2015/08/18/business/dealbook/hacking-case-raises-question-on-securities-fraud.html");
        when(mock.optString("byline", "")).thenReturn("");
        when(mock.optString("published_date", "")).thenReturn("");
        when(mock.getJSONArray("multimedia")).thenReturn(jsonArray);

        NewsEntity expected = new NewsEntity();
        expected.setTitle("Hacking Case Raises Question on Securities Fraud");
        expected.setSummary("Stealing corporate information from computers to make trades certainly looks like insider trading, but it can depend on court jurisdiction.");
        expected.setArticleUrl("http://www.nytimes.com/2015/08/18/business/dealbook/hacking-case-raises-question-on-securities-fraud.html");
        expected.setByline("");
        expected.setPublishedDate("");
        expected.setMediaEntityList(Collections.<MediaEntity>emptyList());

        NewsEntity result = subject.convert(mock);

        Assert.assertEquals(expected, result);
    }

    @Test
    public void testConvert_passCorrectValueWithSingleMultimedia_expectCorrectEntity() throws Exception {
        JSONObject mockJsonMultimediaItem = Mockito.mock(JSONObject.class);
        when(mockJsonMultimediaItem.optString("url", "")).thenReturn("http://static01.nyt.com/images/2015/08/18/business/18db-whitecollar-web/18db-whitecollar-web-thumbStandard.jpg");
        when(mockJsonMultimediaItem.optString("format", "")).thenReturn("Standard Thumbnail");
        when(mockJsonMultimediaItem.optInt("height", 0)).thenReturn(75);
        when(mockJsonMultimediaItem.optInt("width", 0)).thenReturn(75);
        when(mockJsonMultimediaItem.optString("type", "")).thenReturn("image");
        when(mockJsonMultimediaItem.optString("subtype", "")).thenReturn("photo");
        when(mockJsonMultimediaItem.optString("caption", "")).thenReturn("Jeh Johnson, the Secretary of Homeland Security, left, and Paul J. Fishman, United States Attorney for the District of New Jersey, center, after a news conference in Newark on Tuesday.");
        when(mockJsonMultimediaItem.optString("copyright", "")).thenReturn("Karsten Moran for The New York Times");

        JSONArray jsonArray = Mockito.mock(JSONArray.class);
        when(jsonArray.length()).thenReturn(1);
        when(jsonArray.get(0)).thenReturn(mockJsonMultimediaItem);

        JSONObject mock = Mockito.mock(JSONObject.class);
        when(mock.optString("title", "")).thenReturn("Hacking Case Raises Question on Securities Fraud");
        when(mock.optString("abstract", "")).thenReturn("Stealing corporate information from computers to make trades certainly looks like insider trading, but it can depend on court jurisdiction.");
        when(mock.optString("url", "")).thenReturn("http://www.nytimes.com/2015/08/18/business/dealbook/hacking-case-raises-question-on-securities-fraud.html");
        when(mock.optString("byline", "")).thenReturn("By PETER J. HENNING");
        when(mock.optString("published_date", "")).thenReturn("2015-08-18T04:00:00-5:00");
        when(mock.getJSONArray("multimedia")).thenReturn(jsonArray);

        NewsEntity expected = new NewsEntity();
        expected.setTitle("Hacking Case Raises Question on Securities Fraud");
        expected.setSummary("Stealing corporate information from computers to make trades certainly looks like insider trading, but it can depend on court jurisdiction.");
        expected.setArticleUrl("http://www.nytimes.com/2015/08/18/business/dealbook/hacking-case-raises-question-on-securities-fraud.html");
        expected.setByline("By PETER J. HENNING");
        expected.setPublishedDate("2015-08-18T04:00:00-5:00");

        MediaEntity mediaEntity = new MediaEntity();
        mediaEntity.setUrl("http://static01.nyt.com/images/2015/08/18/business/18db-whitecollar-web/18db-whitecollar-web-thumbStandard.jpg");
        mediaEntity.setFormat("Standard Thumbnail");
        mediaEntity.setHeight(75);
        mediaEntity.setWidth(75);
        mediaEntity.setType("image");
        mediaEntity.setSubType("photo");
        mediaEntity.setCaption("Jeh Johnson, the Secretary of Homeland Security, left, and Paul J. Fishman, United States Attorney for the District of New Jersey, center, after a news conference in Newark on Tuesday.");
        mediaEntity.setCopyright("Karsten Moran for The New York Times");
        expected.setMediaEntityList(Collections.singletonList(mediaEntity));

        NewsEntity result = subject.convert(mock);

        Assert.assertEquals(expected, result);
    }
}